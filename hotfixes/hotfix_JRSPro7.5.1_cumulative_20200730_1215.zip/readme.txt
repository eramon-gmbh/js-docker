This hotfix should be applied to JasperReports Server Pro version [7.5.1].
Build version [20200730_1215].

This archive contains hotfixes for JasperReports Server in the following areas:
- JasperReports Server web application
- JasperReports Server buildomatic installation and configuration tool

The hotfix addresses the following bug(s):
* JS-57422 [Case 01860859] Invalid range error message being displayed when we provide zero as filter value for few fields while creating ad hoc view
* JS-55518 [case #01802787] - Report using IE11 in Visualize.js Renders Blank in Waggle
* JS-55770 [case #01794245] Can't deploy JasperServer as Tomcat ROOT context
* JS-58047 [case #01861254] - Domain Composite Join doesn't convert from 711 to 75
* JS-56970 [case #01861886] - Fixing decryption of small (<8) passwords after same db upgrade
* JS-56290 [case #1818197 +1] - MongoDB Connection with User Profile Attribute Failed to Connect When running Report in JRS 7.2.0
* JS-57213 [Case #01841055] Upgrade issues from 7.1 to 7.2 and 7.2 to 7.5 : Wrong names of foreign keys used in upgrade-postgresql-7.2.0-7.5.0-pro.sql script
* JS-57413 Unable to install JRS 7.5.0 with Oracle JDBC proprietary native driver
* JS-58829 [Case #01853335] - xssNonce is not set
* JS-58331 [case # 1865076] Profile attribute does not work for a topic ad hoc view report
* JS-58815 [case 01878486] Highcharts object is not available in Highcharts formatter function when embedded in visualize.js
* JS-34553 [case 01755276] Visualize.js embeddeding accesses login.html before performing authentication

Enclosed archives contain further documentation and installation instructions inside.
